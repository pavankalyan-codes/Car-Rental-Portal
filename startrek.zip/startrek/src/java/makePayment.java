/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author kalyan
 */
public class makePayment extends HttpServlet {


    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
      HttpSession session=request.getSession();
      PrintWriter out=response.getWriter();
      String ordID=(String)session.getAttribute("ordID");
      out.println(ordID);
      int n;
      try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/startrek","root","kingmaker");
            PreparedStatement stmt=conn.prepareStatement("update order_details set pStatus=? where ordId=?;");
            stmt.setString(1,"1");
            stmt.setString(2,ordID);
            n=stmt.executeUpdate();
            if(n>0)
            {
                response.sendRedirect("paymentSuccess.jsp");
            }
            else
            {
                out.println("paymentError.jsp");
            }
        }
        catch(Exception e)
        {
            out.println(e);
        }
    }


}
