/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author kalyan
 */
public class updateCustProfile extends HttpServlet {


    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        String username=request.getParameter("username");
        String password=request.getParameter("password");
        String userid=request.getParameter("uid");
        String uaddress=request.getParameter("address");
        response.setContentType("text/html");
       final String JDBC_DRIVER="com.mysql.jdbc.Driver";
       final String DB_URL="jdbc:mysql://localhost:3306/startrek";
       final String user="root";
       final String pass="kingmaker";
       Connection conn=null;
       PreparedStatement stmt;
       stmt = null;
       int numRows=0;
       PrintWriter out = response.getWriter();
       out.println(username);
       out.println(password);
       try 
        {
           Class.forName(JDBC_DRIVER);
            conn=DriverManager.getConnection(DB_URL,user,pass);
            stmt = conn.prepareStatement("update customers set username=?,upasswd=?,uaddress=? where userid=?;");
            stmt.setString(1,username);
            stmt.setString(2,password);
            stmt.setString(3,uaddress); 
            stmt.setString(4,userid); 
            numRows=stmt.executeUpdate();
            if(numRows>0)
            {
                out.println("updated successfully");
            }
            else
            {
                out.println("not succesfully");
            }
        }
        catch(Exception e)
        {
            out.println(e);
        } 
    }

}
