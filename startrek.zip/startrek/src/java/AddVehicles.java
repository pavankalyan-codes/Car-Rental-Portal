/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.io.File;
import javax.servlet.http.Part;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
/**
 *
 * @author kalyan
 */
@WebServlet("/uploadImage")
@MultipartConfig(maxFileSize = 16177216)
public class AddVehicles extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
       String vname=request.getParameter("vname");
       String vmodel=request.getParameter("vmodel");
       String vid=request.getParameter("vid");
       String vtype=request.getParameter("vtype");
       String vrph=request.getParameter("vrph");
       String vrpk=request.getParameter("vrpk");
       Part file = request.getPart("vimage");
       String fileName=extractfilename(file);
       String savePath="C:\\Users\\kalyan\\Documents\\NetBeansProjects\\startrek\\web\\vimages";
       file.write(savePath+ File.separator +fileName);
       String filePath= "vimages" + File.separator + fileName ;
       response.setContentType("text/html");
       PrintWriter out = response.getWriter();
       final String JDBC_DRIVER="com.mysql.jdbc.Driver";
       final String DB_URL="jdbc:mysql://localhost:3306/startrek";
       final String user="root";
       final String pass="kingmaker";
       Connection conn=null;
       PreparedStatement stmt;
       stmt = null;
       int numRows=0;
       try
        {
            Class.forName(JDBC_DRIVER);
            conn=DriverManager.getConnection(DB_URL,user,pass);
            stmt = conn.prepareStatement("insert into vehicles values(?,?,?,?,?,?,?);");
            stmt.setString(1,vname);
            stmt.setString(2,vmodel);
            stmt.setString(3,vid);
            stmt.setString(4,vtype);
            stmt.setString(5,vrph);
            stmt.setString(6,vrpk);
            stmt.setString(7, filePath);
            numRows=stmt.executeUpdate();
            if(numRows>0)
            {
                out.println("insert successfully");
            }
            else
            {
                out.println("not successfully");
            }
        }
        catch(Exception e)
        {
            out.println(e);
        } 
    }
        private String extractfilename(Part file) {
            String cd = file.getHeader("content-disposition");
            String[] items = cd.split(";");
            for (String string : items) {
                if (string.trim().startsWith("filename")) {
                    return string.substring(string.indexOf("=") + 2, string.length()-1);
                }
            }
            return "";
        }
         
    }
