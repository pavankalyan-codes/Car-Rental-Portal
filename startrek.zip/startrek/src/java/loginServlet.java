import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.*;

/**
 *
 * @author kalyan
 */
public class loginServlet extends HttpServlet {

 
     public void doPost(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException,NullPointerException
    {
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        String uid=req.getParameter("id");
        String pwd=req.getParameter("pwd");
        String role=req.getParameter("role");
        out.println(role+uid+pwd);
        PreparedStatement pst;
        Connection conn;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/startrek","root","kingmaker");
            if(role.equals("cust"))
            {
                pst=conn.prepareStatement("select * from customers where userid=? and upasswd=?;");
                pst.setString(1,uid);
                pst.setString(2,pwd);
                ResultSet rs=pst.executeQuery();
                if(rs.next())
                {
                    HttpSession session = req.getSession();
                    session.setAttribute("name",uid);
                    resp.sendRedirect("customerHome.jsp");

                }
                else
                    out.println("enter correct username or pwd");
                pst.close();
            }
            if(role.equals("man") || role.equals("emp") || role.equals("sb"))
            {
                pst=conn.prepareStatement("select * from employees where empid=? and emppwd=? and emprole=?;");
                pst.setString(1,uid);
                pst.setString(2,pwd);
                pst.setString(3,role);
                ResultSet rs=pst.executeQuery();
                if(rs.next())
                {
                    HttpSession session = req.getSession();
                    session.setAttribute("name",uid);
                    if(role.equals("emp"))
                    {
                        resp.sendRedirect("empHome.jsp");
                    }
                    if(role.equals("man"))
                    {
                        resp.sendRedirect("manHome.jsp");
                    }
                    if(role.equals("sb"))
                    {
                        resp.sendRedirect("sbHome.jsp");
                    }
                    //resp.sendRedirect("customerHome.jsp");

                }
                else
                    out.println("enter correct username or pwd");
                pst.close();
                
            }
            if(role.equals("admin"))
            {
                pst=conn.prepareStatement("select * from admin where adminID=? and adminPWD=?;");
                pst.setString(1,uid);
                pst.setString(2,pwd);
                ResultSet rs=pst.executeQuery();
                
                if(rs.next())
                {
                    HttpSession session = req.getSession();
                    session.setAttribute("name",uid);
                    resp.sendRedirect("adminHome.jsp");
                }
                else
                {
                   out.println("enter correct username or pwd");
                }
                pst.close();
            }
        }
        catch(Exception e)
        {
            out.println(e);
        }
        


    }
}
