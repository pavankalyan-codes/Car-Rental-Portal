/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author kalyan
 */
public class approveVehicle extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        ResultSet rs=null;
        int n=0;
        PrintWriter out=response.getWriter();
        String ordID=request.getParameter("ordID");
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/startrek","root","kingmaker");
            PreparedStatement stmt=conn.prepareStatement("update order_details set apprStatus=? where ordId=?;");
            stmt.setString(1,"1");
            stmt.setString(2,ordID);
            n=stmt.executeUpdate();
            if(n>0)
            {
                response.sendRedirect("orderApprove.jsp");
            }
            else
            {
                out.println("something wrong");
            }
        }
        catch(Exception e)
        {
            out.println(e);
        }
    }


}
