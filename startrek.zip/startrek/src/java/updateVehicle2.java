/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

/**
 *
 * @author kalyan
 */
public class updateVehicle2 extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       String vn=request.getParameter("vname");
       String vmodel=request.getParameter("vmodel");
       String vid=request.getParameter("vid");
       String vtype=request.getParameter("vtype");
       String vrph=request.getParameter("vrph");
       String vrpk=request.getParameter("vrpk");
       response.setContentType("text/html");
       final String JDBC_DRIVER="com.mysql.jdbc.Driver";
       final String DB_URL="jdbc:mysql://localhost:3306/startrek";
       final String user="root";
       final String pass="kingmaker";
       Connection conn=null;
       PreparedStatement stmt;
       stmt = null;
       int numRows=0;
       PrintWriter out = response.getWriter();
       out.println(vn);
       out.println(vmodel);
        try 
        {
           Class.forName(JDBC_DRIVER);
            conn=DriverManager.getConnection(DB_URL,user,pass);
            stmt = conn.prepareStatement("update vehicles set vname=?,vmodel=?,vtype=?,vrph=?,vrpk=? where vid=?;");
            stmt.setString(1,vn);
            stmt.setString(2,vmodel);
            stmt.setString(3,vtype);
            stmt.setString(4,vrph);
            stmt.setString(5,vrpk);
            stmt.setString(6,vid);
        
            numRows=stmt.executeUpdate();
            if(numRows>0)
            {
                out.println("updated successfully");
            }
            else
            {
                out.println("not succesfully");
            }
        }
        catch(Exception e)
        {
            out.println(e);
        } 
    }
}
