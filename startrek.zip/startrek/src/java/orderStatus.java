/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author kalyan
 */
public class orderStatus extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        String ordID=request.getParameter("ordID");
        HttpSession session=request.getSession();
        session.setAttribute("ordID",ordID);
        ResultSet rs=null;
        PrintWriter out = response.getWriter();
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/startrek","root","kingmaker");
            String sql="select apprStatus,confirmStatus,delStatus from order_details where ordId=?;";
            PreparedStatement stmt=conn.prepareStatement(sql);
            stmt.setString(1,ordID);
            rs=stmt.executeQuery();
            
            if(rs.next())
            {
                if(rs.getString(1).equals("0"))
                {   
                    
                    out.println("order pending for approval");
                    return;
                }
                if(rs.getString(2).equals("0"))
                {   
                    out.println("waiting for payment");
                    return;
                }
                if(rs.getString(3).equals("0"))
                {   
                    out.println("order out for delivery");
                    return;
                }
                
            }
            else
            {
                out.println("order id not found");
            }
        }
        catch(Exception e)
        {
            out.println(e);
        }
        
    }  
}
