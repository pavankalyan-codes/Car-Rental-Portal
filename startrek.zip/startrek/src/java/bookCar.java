/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author kalyan
 */
public class bookCar extends HttpServlet {

    
   
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        HttpSession session = request.getSession();
        String cid=(String)session.getAttribute("cid");
        String vid=(String)session.getAttribute("vid");
        String noh=request.getParameter("noh");
        out.println(noh);
        String rate=(String)session.getAttribute("vrph");
        out.println(rate);
        int amount=(Integer.parseInt(rate))*(Integer.parseInt(noh));
        String am=Integer.toString(amount);
        String ordID=cid+vid;
        String apprStatus="0";
        String confirmStatus="0";
        String delStatus="0";
        String pstatus="0";
        String pamount=request.getParameter("addPayment");
        int n=0;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/startrek","root","kingmaker");
            String sql="insert into order_details values(?,?,?,?,?,?,?,?,?);";
            PreparedStatement stmt=conn.prepareStatement(sql);
            stmt.setString(1,cid);
            stmt.setString(2,vid);
            stmt.setString(3,ordID);
            stmt.setString(4,apprStatus);
            stmt.setString(5,confirmStatus);
            stmt.setString(6,delStatus);
            stmt.setString(7,pamount);
            stmt.setString(8,pstatus);
            
            n=stmt.executeUpdate();
            if(n>0)
            {
                session.setAttribute("ordID",ordID);
                response.sendRedirect("orderSuccess.jsp");
                
                
            }
            else
                out.println("something wrong with making order");
            
        }
        catch(Exception e)
        {
            out.println(e);
        }

}
}
