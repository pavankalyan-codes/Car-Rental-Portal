/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

/**
 *
 * @author kalyan
 */
public class addEmp extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
       String empname=request.getParameter("username");
       String empid=request.getParameter("uid");
       String emppwd=request.getParameter("password");
       String role=request.getParameter("role");
       response.setContentType("text/html");
       PrintWriter out = response.getWriter();
       final String JDBC_DRIVER="com.mysql.jdbc.Driver";
       final String DB_URL="jdbc:mysql://localhost:3306/startrek";
       final String user="root";
       final String pass="kingmaker";
       Connection conn=null;
       PreparedStatement stmt=null;
       int n=0;
       try
       {
           Class.forName(JDBC_DRIVER);
           conn=DriverManager.getConnection(DB_URL,user,pass);
           String sql="insert into employees values(?,?,?,?);";
           stmt=conn.prepareStatement(sql);
           stmt.setString(1,empname);
           stmt.setString(2,empid);
           stmt.setString(3,emppwd);
           stmt.setString(4,role);
           n=stmt.executeUpdate();
           stmt.close();
         }
       catch(SQLException e)
       {
           out.println(e);
       }
       catch(Exception e)
       {}
       if(n>0)
       {
           out.println("support personnel successfully added");
       }
       
       
       
        
    }

}
