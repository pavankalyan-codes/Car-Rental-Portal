/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author kalyan
 */
public class deleteVehicle extends HttpServlet {

     protected void doGet(HttpServletRequest request, HttpServletResponse response)   
             throws ServletException, IOException { 
        final String JDBC_DRIVER="com.mysql.jdbc.Driver";
       final String DB_URL="jdbc:mysql://localhost:3306/startrek";
       final String user="root";
       final String pass="kingmaker";
       Connection conn=null;
       PreparedStatement stmt=null;
       int n=0,i=0;
       response.setContentType("text/html");
       PrintWriter out = response.getWriter();
       String vid=request.getParameter("vid");
       ResultSet rs=null;
        try
        {
           Class.forName(JDBC_DRIVER);
           conn=DriverManager.getConnection(DB_URL,user,pass);
           String delimg="select vimagepath from vehicles where vid=?;";
           stmt=conn.prepareStatement(delimg);
           stmt.setString(1,vid);
           out.println(vid);
           rs=stmt.executeQuery();
           
           if(rs.next())
           {
               out.println(rs.getString(1));
                File file = new File("C:\\Users\\kalyan\\Documents\\NetBeansProjects\\startrek\\web\\"+rs.getString(1));
                file.delete();
            }
           String sql="delete from vehicles where vid=?;";

           
           stmt=conn.prepareStatement(sql);
           stmt.setString(1,vid);
           n=stmt.executeUpdate();
           if(n>0)
            {   
                //out.println("path deleted from db");
               response.sendRedirect("modifyVehicles.jsp");
            } 
        }
        catch(Exception e)
        {
            out.println(e);
        }
         
    }  


}
